package com.cg.dw.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CreditCardTransaction;

public interface CreditCardTransactionDao {
	boolean verifyCreditTransactionId(BigInteger transactionId) throws IBSException;

	//List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException;

	BigInteger getCMUci(BigInteger transactionId) throws IBSException;
	BigInteger getCreditCardNumber(BigInteger transactionId) throws IBSException;

	BigInteger getCreditMismatchTranscId(String queryId) throws  IBSException;

	List<CreditCardTransaction> getCreditMismatchTransc(BigInteger transactionId) throws IBSException;

	List<CreditCardTransaction> getCreditTrans(LocalDate startDate, LocalDate endDate, BigInteger creditCardNumber)
			throws IBSException;

	boolean checkTransactions(BigInteger creditCardNumber) throws IBSException;

}
