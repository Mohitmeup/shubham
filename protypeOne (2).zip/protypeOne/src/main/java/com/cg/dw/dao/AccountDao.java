package com.cg.dw.dao;

import java.math.BigInteger;

import com.cg.dw.exception.IBSException;

public interface AccountDao {


	boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException;
	BigInteger getUci(BigInteger accountNumber) throws IBSException;

	

}
