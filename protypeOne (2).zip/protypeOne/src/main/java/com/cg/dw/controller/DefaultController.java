package com.cg.dw.controller;

import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.service.CustomerService;

@Controller
public class DefaultController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping({ "/", "/home" })
	public String showHome() {
		return "homePage";
	}

	@RequestMapping("/menu")
	public String showMenu() {
		return "menuPage";
	}

	@RequestMapping("/customer")
	public String showCardHome() {
		return "cardsHomePage";
	}

	@RequestMapping("/cardChoice")
	public String showCardHome1() {
		return "cardMenuPage";
	}

	@RequestMapping("/debitMenu")
	public String showdebitMenu() {
		return "debitMenuPage";

	}

	@RequestMapping("/creditMenu")
	public String showCreditMenu() {
		return "creditMenuPage";
	}

	@RequestMapping("/debitCards")
	public String showDebitCardHome() {
		return "debitHomeMenuPage";
	}

	@RequestMapping("/creditCards")
	public String showCreditCardHome() {
		return "creditHomeMenuPage";
	}
	// @RequestMapping(value="/errors",method=RequestMethod.GET)
	// public String error(){
	// return "pageNotFound";
	// }

	@RequestMapping("/banker")
	public String showBankHome() {
		return "bankHomePage";
	}

	@RequestMapping("/viewStatus")
	public String showStatus() {
		return "queryStatus";
	}

	@RequestMapping(value = "/queryStatus", method = RequestMethod.POST)
	public ModelAndView viewQueryStatus(@RequestParam("UCI") BigInteger uci) {
		DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		List<CaseIdBean> caseIdBeans;
		try {
			caseIdBeans = customerService.listAllQueries(uci);
		} catch (IBSException e) {
			String message = e.getMessage();

			return new ModelAndView("errorPage", "errorMessage", message);
		}

		ModelAndView mv = new ModelAndView("listServiceRequests", "output", caseIdBeans);
		mv.addObject("dtF", dtFormat);
		return mv;

	}

	@RequestMapping(value = "/displayServiceRequests")
	public ModelAndView queryStatus(@RequestParam("customerRefId") String customerReferenceId) {
		String output = "";
		try {
			String status = customerService.viewServiceRequestStatus(customerReferenceId);
			output = "Status of your request is '" + status + "'";
			return new ModelAndView("outputPage", "output", output);
		} catch (IBSException e) {
			output = e.getMessage();
			return new ModelAndView("errorPage", "output", output);
		}
	}

}
